typedef unsigned int   uint;
typedef unsigned long uint32;
typedef unsigned short ushort;
typedef unsigned char  uchar;
typedef uint pde_t;
